import React from 'react';
import {BrowserRouter as Router,Switch,Route,Redirect} from 'react-router-dom'
import './App.css';
import MainPage from './Pages/index'
import Assignment1 from './Pages/Assignment1';
import Assignment4 from './Pages/Assignment4';
import FileNotFound from './Pages/error';
import Assignment5 from './Pages/Assignment5/Main';
import Assignment7 from './Pages/Assignment7/Main';
import Assignment8 from './Pages/Assignment8/Main';
import Assignment10 from './Pages/Assignment10'
import Assignment11 from './Pages/Assignment11/Main'
import Assignmnet6 from './Pages/Assignment6/Main';
import Assignment9 from './Pages/Assignment9';
import Assignment3 from './Pages/Assignment3/Assignment3';
import Assignment2 from './Pages/Assignment2/Table';
import AddMovie from './Pages/Assignment11/AddMovie';
class App extends React.Component {
  render(){
  return (
    <Router>
     <Switch>
      <Route exact path="/" component={MainPage}/>
      <Route exact path="/Assignment1" component={Assignment1}/>
      <Route exact path='/Assignment2' component={Assignment2} />
      <Route exact path='/Assignment3' component={Assignment3} />
      <Route exact path='/Assignment4' component={Assignment4} />
      <Route exact path='/Assignment5' component={Assignment5} />
      <Route exact path='/Assignment6' component={Assignmnet6} />
      <Route exact path='/Assignment7' component={Assignment7} />
      <Route exact path='/Assignment8' component={Assignment8}/>
      <Route exact path='/Assignment9' component={Assignment9} />
      <Route exact path='/Assignment10' component={Assignment10} />
      <Route exact path='/Assignment11' component={Assignment11} />
      <Route exact path='Assignment11/AddMovie' component={AddMovie} />
      <Route exact path="/FileNotFound" component={FileNotFound}/>
      <Redirect to="FileNotFound" />
     </Switch>
    </Router>
  );
  }
}

export default App;
