import React from 'react'
const AddMovie=(props)=>{
   const handleSubmit=()=>{
        console.log('submitted')
        return false
    }
    return(
        <div>
          <form onSubmit={handleSubmit}>
              <p>movieID</p><input type='number' id='movieID'/><br/>
              <p>movieName</p><input type='username'  id='movieName'/><br/>
              <p>LeadActor</p><input type='username'  id='LeadActor'/><br/>
              <p>LeadActress</p><input type='username'  id='LeadActress'/><br/>
              <p>Language</p><input type='username'  id='Language'/><br />
              <input type='submit' value='AddMovie' />
              {console.log(props.match.params)}
          </form>
        </div>
    )
}
export default AddMovie;