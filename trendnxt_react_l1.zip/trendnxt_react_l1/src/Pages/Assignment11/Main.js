import React from 'react'
import Details from './Details'
import './Main.css'
import MovieDetails from './MovieDetails'
class Assignment11 extends React.Component{
    constructor(){
        super()
        this.state={
            movieDetails:[
                {
                    MovieID:1, 
                    MovieName:'bahubali1',
                    LeadActor:'prabhas',
                    LeadActress:'Anuskha',
                    YearOfRelease:2016,
                    Language:'telugu'
                },
                {
                    MovieID:2, 
                    MovieName:'bahubali2',
                    LeadActor:'prabhas',
                    LeadActress:'Anuskha',
                    YearOfRelease:2018,
                    Language:'telugu'
                }
            ],
            isToggle:false,
            MovieID:'',
            MovieName:'',
            LeadActor:'',
            LeadActress:'',
            Language:'',
            arr:[],
            movieById:[],
            id:0,
            showDetails:false,
            showSearch:false,
            h1View:false,

        }
        
    }
    handleDelete=(id)=>{
        const details=this.state.movieDetails.filter(item=> item.MovieID!==id)
        this.setState({movieDetails:details})
    }
    handleSubmit=(event)=>{
        event.preventDefault();
        var id=parseInt(this.state.MovieID)
        var arr={
            MovieID:id,
            MovieName:this.state.MovieName,
            LeadActor:this.state.LeadActor,
            LeadActress:this.state.LeadActress,
            Language:this.state.Language
        }
    var addnewMovie=[...this.state.movieDetails,arr]
        this.setState({movieDetails:addnewMovie})
        this.setState({isToggle:false})
        alert('movie Added succesfully')
     
    }
    handleMovieID=(event)=>{
        var a=event.target.value
        this.setState({MovieID:a})
    }
    handleMovieName=(event)=>{
        var a=event.target.value
        this.setState({MovieName:a})
    }
    handleLeadActor=(event)=>{
        var a=event.target.value
        this.setState({LeadActor:a})
    }
    handleLeadActress=(event)=>{this.setState({LeadActress:event.target.value})}
    handleLanguage=(event)=>{
        this.setState({Language:event.target.value})
    }
    
    getId=(event)=>{
        this.setState({id:event.target.value})
    }
    getMovieById=(event)=>{
        event.preventDefault();
       this.setState({movieById:this.state.movieDetails[this.state.id-1]})
       this.setState({h1View:true})
       
    }
    addMovie=()=>{
        this.setState({isToggle:!this.state.isToggle})
       this.setState({showSearch:false})
        this.setState({showDetails:false})
        this.setState({h1View:false})
        
    }
    handleShowMovies=()=>{
        this.setState({showDetails:!this.state.showDetails})
        this.setState({showSearch:false})
        this.setState({isToggle:false})
        this.setState({h1View:false})
    }
    handleSearch=()=>{
        this.setState({showSearch:!this.state.showSearch})
        this.setState({showDetails:false})
        this.setState({isToggle:false})
    }
    render(){
        const details=this.state.movieDetails.map(item=> <Details showDetails={this.state.showDetails} key={item.MovieID} id={item.MovieID} item={item} handleDelete={this.handleDelete}/>)
        return(
         <div style={{textAlign:'center',marginTop:'30px'}}>
              <button onClick={this.handleShowMovies}>Show All Movies</button>
             <button onClick={this.addMovie}>AddMovie</button>
             <button onClick={this.handleSearch}>Search By Movie Id</button>
            {details}
            
            <form onSubmit={this.handleSubmit} style={{display:this.state.isToggle?'block':'none'}}>
              <p>movieID</p><input type='number' id='movieID' onChange={this.handleMovieID}/><br/>
              <p>movieName</p><input type='username'  id='movieName'  onChange={this.handleMovieName}/><br/>
              <p>LeadActor</p><input type='username'  id='LeadActor' onChange={this.handleLeadActor} /><br/>
              <p>LeadActress</p><input type='username'  id='LeadActress' onChange={this.handleLeadActress}/><br/>
              <p>Language</p><input type='username'  id='Language' onChange={this.handleLanguage}/><br /><br/>
              <input type='submit' value='submit' onClick={this.handleSubmit}/>
          </form>
          <form onSubmit={this.getMovieById} style={{display:this.state.showSearch?'block':'none',marginTop:'40px'}}>
              <h1>search by movie Id</h1><br/>
              <input type='number'  onChange={this.getId}/><br /><br />
              <input type='submit' />
          </form>
          <MovieDetails item={this.state.movieById} h1View={this.state.h1View}/>
         </div>
     )
 }
}
export default Assignment11;