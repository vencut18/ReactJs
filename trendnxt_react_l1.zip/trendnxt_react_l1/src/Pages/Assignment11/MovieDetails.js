import React from 'react'

const MovieDetails=(props)=>{
    return(
      <div style={{display:props.h1View?'block':'none'}}>
        <h1>MovieID: {props.item.MovieID}</h1>
         <h1>MovieName: {props.item.MovieName}</h1>
         <h1>LeadActor: {props.item.LeadActor}</h1>
         <h1>LeadActress: {props.item.LeadActress}</h1>
         <h1>Language: {props.item.Language}</h1> 
      </div>
  )
}
export default MovieDetails;