import React from 'react'
const Details=(props)=>{
    return(
        <div style={{display:props.showDetails?'block':'none'}}>
         <h1>MovieID: {props.item.MovieID}</h1>
         <h1>MovieName: {props.item.MovieName}</h1>
         <h1>LeadActor: {props.item.LeadActor}</h1>
         <h1>LeadActress: {props.item.LeadActress}</h1>
         <h1>Language: {props.item.Language}</h1> 
         <button onClick={() => props.handleDelete(props.item.MovieID)}>delete</button>        
        </div>
    )
}
export default Details;