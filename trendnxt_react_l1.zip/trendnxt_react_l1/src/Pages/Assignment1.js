import React from 'react'
class Assignment1 extends React.Component{
render(){
    let styles={
        color:'green',
        textAlign:'center',
        fontSize:100
    }
    return(
        <div>
            <h1 style={styles}>Happy Learning React...!</h1>
        </div>
    )
}
}
export default Assignment1;