import React from 'react'

const Assignment2=()=>{
    return(
        <div style={{
            textAlign:'center'
        }}>
            <h1>Employee details</h1>
            <table align='center'>
            <thead>
            <tr >
              <th style={{border:'1px solid black',backgroundColor:'none'}}>Employee ID</th>
              <th style={{border:'1px solid black'}}>Employee Name</th>
              <th style={{border:'1px solid black'}}>Employee EmailID</th>
          </tr>
          </thead>
          <tbody>
          <tr >
              <td style={{border:'1px solid black'}}>20090230</td>
              <td style={{border:'1px solid black'}}>vencut</td>
              <td style={{border:'1px solid black'}}>vencut@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td style={{border:'1px solid black'}}>20090231</td>
              <td style={{border:'1px solid black'}}>venkat</td>
              <td style={{border:'1px solid black'}}>venkat@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td style={{border:'1px solid black'}}>20090232</td>
              <td style={{border:'1px solid black'}}>venket</td>
              <td style={{border:'1px solid black'}}>venket@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td style={{border:'1px solid black'}}>20090230</td>
              <td style={{border:'1px solid black'}}>venkata ramana</td>
              <td style={{border:'1px solid black'}}>venkataramana@wipro.com</td>
          </tr>
          </tbody>
            </table>
        </div>
    )
}
export default Assignment2