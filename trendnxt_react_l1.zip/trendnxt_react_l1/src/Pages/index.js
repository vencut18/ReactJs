import React from 'react'
import {Link} from 'react-router-dom'
class MainPage extends React.Component{
    render(){
        return(
            <div style={{textAlign:'center',listStyle:'none',margin:'20px'}}>
            <h1>Welcome to the Home Page</h1>
            <ul style={{listStyle:'none',fontSize:'20px',color:'green'}}>
            <li><Link to='Assignment1'>Assignment1</Link></li><br />
            <li><Link to='Assignment2'>Assignment2</Link></li><br />
            <li><Link to='Assignment3'>Assignment3</Link></li><br />
            <li><Link to='Assignment4'>Assignment4</Link></li><br />
            <li><Link to='Assignment5'>Assignment5</Link></li><br />
            <li><Link to='Assignment6'>Assignment6</Link></li><br />
            <li><Link to='Assignment7'>Assignment7</Link></li><br />
            <li><Link to='Assignment8'>Assignment8</Link></li><br />
            <li><Link to='Assignment9'>Assignment9</Link></li><br />
            <li><Link to='Assignment10'>Assignment10</Link></li><br />
            <li><Link to='Assignment11'>Assignment11</Link></li>
            
            </ul>
            </div>
        )
    }
}
export default MainPage;