import React from 'react'
import App from './App'
class Assignment5 extends React.Component{
    constructor(){
        super()
        this.state={
            companyName:'',
            companyLocation:'',
            formView:false
        }
    }
    handleCompanyName=(event)=>{
        this.setState({companyName:event.target.value})
    }
    handleCompanyLocation=(event)=>{
        this.setState({companyLocation:event.target.value})
    }
    handleSubmit=(event)=>{
        event.preventDefault();
        this.setState({formView:false})
    }
    handleClick=()=>{
       this.setState({formView:true})
    }
    render(){
        return(
            <div style={{marginTop:'30px',textAlign:'center'}}> 
                <button onClick={this.handleClick}>click here to give input</button>
                <form onSubmit={this.handleSubmit} style={{textAlign:'center',display:this.state.formView?'block':'none'}}>
                    <h1>Please enter the details</h1>
                    <input type='username' onChange={this.handleCompanyName} /><br />
                    <input type='username' onChange={this.handleCompanyLocation} /><br />
                    <input type='submit' />
                </form>
               <App companyName={this.state.companyName} companyLocation={this.state.companyLocation} formView={this.state.formView}/>
            </div>
        )
    }
}
export default Assignment5