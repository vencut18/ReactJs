import React from 'react'

const App=(props)=>{
    return(
       <div style={{display:props.formView?'none':'block'}}>
         <h1 style={{textAlign:'center',color:'grey'}}>Company Name: {props.companyName.length===0?'Wirpo':props.companyName}</h1>
         <h1 style={{textAlign:'center', color:'grey'}}>Location: {props.companyLocation.length===0?'Banglore':props.companyLocation}</h1>
       </div>
    )
}
export default App;