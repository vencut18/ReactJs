import React from 'react';
import './Assignment3.css'
const Assignment3=()=>{
return(
    <div>
      <h1 style={{textAlign:'center',color:'green'}}>Employee Details</h1>
      <table align='center' className='table2'>
          <thead>
              <tr >
              <th style={{backgroundColor:'cyan'}}>Employee ID</th>
              <th style={{backgroundColor:'cyan'}}>Employee Name</th>
              <th style={{backgroundColor:'cyan'}}>Employee EmailID</th>
          </tr>
          </thead>
          <tbody>
          <tr id='tr1'>
              <td>20090230</td>
              <td>vencut</td>
              <td>vencut@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td>20090231</td>
              <td>venkat</td>
              <td>venkat@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td>20090232</td>
              <td>venket</td>
              <td>venket@wipro.com</td>
          </tr>
          <tr id='tr1'>
              <td>20090230</td>
              <td>venkata ramana</td>
              <td>venkataramana@wipro.com</td>
          </tr>
          </tbody>
      </table>
    </div>
)
}
export default Assignment3;