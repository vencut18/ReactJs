import React from 'react'
const FileNotFound=()=>{
    return(
        <div>
        <h1>404 file not found</h1>
        </div>
    )
}
export default FileNotFound;