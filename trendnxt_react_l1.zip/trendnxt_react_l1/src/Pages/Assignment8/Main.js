import React from 'react'
class Assignment8 extends React.Component{
    constructor(){
        super()
        this.state={
            a:1,
            row:[]
        }
        this.handleClick=this.handleClick.bind(this)
    }
     handleClick(){
        var a=this.state.a
        var row=this.state.row.slice();
        row.push('5 * '+(a)+ ' = '+(5*a))
        this.setState({a:a+1})
        this.setState({row:row})
    }
   
    render(){
         
        return(
            <div className='main' style={{textAlign:'center',marginTop:'30px',fontSize:'30px',backgroundColor:'grey'}}>
              <button onClick={this.handleClick} style={{fontSize:'30px'}}>Generate MultiplicationTable of 5</button><br/>
            {this.state.row.map(item=>{return <div key={item}>{item}</div>})}
            </div>
        )
    }
}
export default Assignment8;