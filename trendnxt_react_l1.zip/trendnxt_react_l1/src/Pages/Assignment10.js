import React from 'react'

class Assignment10 extends React.Component{
constructor(){
    super()
    this.state={
        mathematics:0,
        science:0,
        english:0,
        social:0
    }
    this.handleChange=this.handleChange.bind(this)

    
}
handleSubmit=(event)=>{
    event.preventDefault();
    console.log(this.state.mathematics)
    console.log('hello')
    let sum=parseInt(this.state.mathematics)+parseInt(this.state.science)+parseInt(this.state.english)+parseInt(this.state.social)
    alert('Average of all the subjects is '+sum/4)
    event.preventDefault();
}
handleChange(){
    var mat=document.getElementById('mat').value
    var sci=document.getElementById('sci').value
    var eng=document.getElementById('eng').value
    var soc=document.getElementById('soc').value
    this.setState({mathematics:mat})
    this.setState({science:sci})
    this.setState({english:eng})
    this.setState({social:soc})

}
render(){
    return(
        
        <div style={{textAlign:'center'}}>
            <h1>Find Average of the subjects</h1>
            <form onSubmit={this.handleSubmit}>
                <p>mathematics</p><input type='number' min='0' max='100' id='mat' style={{width: "170px"}} placeholder='Enter your marks' onChange={this.handleChange}required/>
                <p>science</p><input type='number' min='0' max='100' size='20px' style={{width: "170px"}} placeholder='Enter your marks' id='sci' onChange={this.handleChange} required/>
                <p>english</p><input type='number' min='0' max='100' id='eng' style={{width: "170px"}} placeholder='Enter your marks' onChange={this.handleChange} required/>
                <p>social</p><input type='number' min='0' max='100' id='soc' style={{width: "170px"}}  placeholder='Enter your marks' onChange={this.handleChange} required/><br/>
                <input type='submit' value='FindAverage' style={{marginTop:'20px'}}/>
            </form>
            </div>
    )
}
}
export default Assignment10