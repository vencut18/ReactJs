import React from 'react'

const App=(props)=>{
    var name=props.name
    var preferedCity1=props.preferedCity1
    var preferedCity2=props.preferedCity2
    var age=props.age
    var tableView=props.tableView
    return(
        <div style={{fontSize:'30px',textAlign:'center',display:tableView?'block':'none',marginTop:'20px'} }>
           <table align='center'>
               <tbody>
               <tr>
                   <td>Name:</td>
                   <td>{name.length>0?name:'Steve'}</td>
               </tr>
               <tr>
                   <td>preferedCities</td>
                   <td>{preferedCity1.length>0?preferedCity1:'Banglore'}<br />{preferedCity2.length>0?preferedCity2:'Chennai'}</td>
               </tr>
               <tr>
                   <td>Age:</td>
                   <td>{(age>18 && age<60)?age:'18'}</td>
               </tr>
               </tbody>
           </table>
        </div>
    )
}
export default App;