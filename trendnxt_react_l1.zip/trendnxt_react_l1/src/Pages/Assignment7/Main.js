import React from 'react'
import App from './App'
class Assignment7 extends React.Component{
    constructor(){
        super()
        this.state={
            name:'',
            preferedCity1:'',
            preferedCity2:'',
            age:'',
            isToggled:true,
            tableView:true,
            formView:false
        }
    }
    handleNameChange=(event)=>{
        this.setState({name:event.target.value})
        this.setState({tableView:false})
    }
    handlePrecity1Change=(event)=>{
        this.setState({preferedCity1:event.target.value})
    }
    handlePrecity2Change=(event)=>{
        this.setState({preferedCity2:event.target.value})
    }
    handleAge=(event)=>{
        this.setState({Age:event.target.value})
    }
    handleSubmit=(event)=>{
        event.preventDefault();
        this.setState({tableView:!this.state.tableView})
        this.setState({formView:false})
    }
    handleClick=()=>{
      this.setState({formView:true})
    }
    render(){
        return(
            <div style={{textAlign:'center',marginTop:'40px'}}>
                <button onClick={this.handleClick}>Click here to give User Defined Values</button>
                <form onSubmit={this.handleSubmit} style={{display:this.state.formView?'block':'none'}} >
                  <label>Name: </label><br/><input type='username' onChange={this.handleNameChange}/><br />
                  <label>preferedCity1</label><br/><input type='username' onChange={this.handlePrecity1Change}/><br />
                  <label>preferedCity2</label><br/><input type='username' onChange={this.handlePrecity2Change}/><br />
                  <label>Age:</label><br/><input type='number' min='0' onChange={this.handleAge}/><br />
                  <input type='submit' value='submit' />
                </form>
              <App name={this.state.name} tableView={this.state.tableView} preferedCity1={this.state.preferedCity1} preferedCity2={this.state.preferedCity2}  age={this.state.age} />
            </div>
        )
    }
}
export default Assignment7;