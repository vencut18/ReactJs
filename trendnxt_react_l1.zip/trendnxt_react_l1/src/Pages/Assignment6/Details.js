import React from 'react'

const Details=(props)=>{
   
    return(
        <div>
            <table align='center' style={{border:'1px solid black',width:'600px'}}>
                <tbody>
                <tr>
                 <td style={{border:'1px solid black',width:'180px'}}>{props.items.studentId}</td>
                 <td style={{border:'1px solid black',width:'230px'}}>{props.items.studentName}</td>
                 <td style={{border:'1px solid black',width:'232px'}}>{props.items.studentMarks}</td>
                </tr>
                </tbody>
            </table>
        </div>
    )
}
export default Details