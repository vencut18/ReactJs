import React from 'react'

const Header=()=>{
    return(
        <div>
           <h1 style={{textAlign:'center', color:'cyan'}}>Student Details Of the Class</h1>
           <table align='center' style={{border:'1px solid black',width:'600px'}}>
               <thead>
               <th style={{border:'1px solid black'}}>Student Id</th>
               <th style={{border:'1px solid black'}} >student Name</th>
               <th style={{border:'1px solid black'}}>Student Marks</th>
               </thead>
           </table>
        </div>
    )
}
export default Header