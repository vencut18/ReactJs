import React from 'react'
import Header from './Header'
import Details from './Details'
class Assignment6 extends React.Component{
    constructor(){
        super()
        this.state={
            studentDetails:[
                {
                    studentId:230,
                    studentName:'venkat',
                    studentMarks:'99'
                },
                {
                    studentId:231,
                    studentName:'vencut',
                    studentMarks:'91'
                },
                {
                    studentId:232,
                    studentName:'venket',
                    studentMarks:'92'
                },
                {
                    studentId:233,
                    studentName:'vencat',
                    studentMarks:'93'
                },
                {
                    studentId:234,
                    studentName:'venkut',
                    studentMarks:'94'
                },
            ]
        }
    }
    render(){
        const details=this.state.studentDetails.map(row=><Details key={row.studentId} id={row.studentId} items={row} />)
         return(
             <React.Fragment>
                 <Header />
                 {details}
             </React.Fragment>
         )
    }
}
export default Assignment6