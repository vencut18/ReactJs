import React from 'react'
class Assignment4 extends React.Component{
    constructor(){
        super()
        this.state={
            rows:[],
            button:true
        }
        this.handleClick=this.handleClick.bind(this);
    }
    handleClick(){
        var a=this.state.rows.slice();
        for(var i=1;i<=10;i++){
          a.push('5 *'+i+'='+(5*i))
        }
        this.setState({rows:a})
    }
    componentDidUpdate(){
      var button=document.getElementById('button')
      button.style.display='none'
    }
    render(){
        return(
            <div style={{textAlign:'center'}}> 
                <h1>Multiplication Table of 5</h1>
                <button onClick={this.handleClick} id='button'>Generate Multiplication table of 5</button>
                {this.state.rows.map((item,key)=>{return <div key={item} style={{fontSize:'20px'}}>{item}</div>})}
            </div>
        )
    }
}
export default Assignment4;