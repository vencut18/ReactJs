import React from 'react'
class Assignment9 extends React.Component{
constructor(){
    super()
    this.state={
        isToggled:true
    }
}
componentDidMount(){
    console.log('did mount called')
}
componentWillMount(){
    console.log('will mount')
}
componentDidUpdate(){
    console.log('did update')
}

componentWillUnmount(){
    console.log('will unmount')
}
handleClick=()=>{
this.setState({isToggled:!this.state.isToggled})
}
render(){
    console.log('render method')
    return(
        <div style={{textAlign:'center'}}>
            {console.log('return statement')}
           <div onClick={this.handleClick} style={{display:this.state.isToggled?'block':'none'}}>
               <h1>Click to Hide the div Tag</h1>
           </div>
           <p>
               <b>Quote For the Day: </b>Failure is not the antonym of success it is the part of success
           </p>
           <h1 style={{display:this.state.isToggled?'none':'block'}}>Now LOOK at the console for order of execution of statements</h1>
        </div>
        
    )
}
}
export default Assignment9